package com.example.submission2.favorite

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.submission2.database.FavoriteDao
import com.example.submission2.database.FavoriteUsers
import com.example.submission2.database.FavoriteUsersDatabase


class FavoriteUsersViewModel(application : Application) : AndroidViewModel(application) {
    private var favoriteDao: FavoriteDao?
    private var favoriteUsersDatabase: FavoriteUsersDatabase?

    init {
        favoriteUsersDatabase = FavoriteUsersDatabase.getDatabase(application)
        favoriteDao = favoriteUsersDatabase?.favoriteDao()
    }

    fun getFavoriteUsers() : LiveData<List<FavoriteUsers>>?{
        return favoriteDao?.getFavoriteUsers()
    }
}