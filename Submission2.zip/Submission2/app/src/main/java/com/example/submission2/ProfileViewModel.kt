package com.example.submission2

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.submission2.api.RetrofitConfig
import com.example.submission2.database.FavoriteDao
import com.example.submission2.database.FavoriteUsersDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Response
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.submission2.database.FavoriteUsers

class ProfileViewModel(application: Application) : AndroidViewModel(application){


    private val userProfil = MutableLiveData<GithubUsers>()
    private val _showLoading : MutableLiveData<Boolean> = MutableLiveData()
    private val _errorMessage : MutableLiveData<String> = MutableLiveData()
    private val favoriteUsersDatabase: FavoriteUsersDatabase = FavoriteUsersDatabase.getDatabase(application)
    private var favoriteDao: FavoriteDao? = favoriteUsersDatabase.favoriteDao()
    private val _userFavorit : MutableLiveData<Boolean> = MutableLiveData()

    fun getUserProfil(username: String?){
        _showLoading.value = true
        val client = RetrofitConfig.apiService.getUsersProfil(username)
        client.enqueue(object : retrofit2.Callback<GithubUsers>{

            override fun onResponse(call: Call<GithubUsers>, response: Response<GithubUsers>) {
                if (response.isSuccessful) {
                    userProfil.value = response.body()
                    _showLoading.value = false
                }else{
                    _showLoading.value = false
                    _errorMessage.value = "failed to load data"
                }
            }

            override fun onFailure(call: Call<GithubUsers>, t: Throwable) {
                _showLoading.value = false
                _errorMessage.value = t.message.toString()
            }


        } )
    }

    fun getProfil(): LiveData<GithubUsers> {
        return userProfil

    }    fun getLoading():LiveData<Boolean>{
        return _showLoading
    }
    fun getError():LiveData<String>{
        return _errorMessage
    }

/*    fun insertDeleteFavorite(userFavorit: FavoriteUsers, deleteInsert: Boolean) {
        if (deleteInsert) {
            viewModelScope(Dispatchers.IO).launch {
                favoriteDao?.delete(userFavorit)
            }
        } else {
            CoroutineScope(Dispatchers.IO).launch {
                favoriteDao?.insert(userFavorit)
            }
        }
    }*/

/*    fun insertDeleteFavorite(userFavorit: FavoriteUsers, deleteInsert: Boolean) = viewModelScope.launch{
        withContext(Dispatchers.IO) {
            if (deleteInsert) {

                favoriteDao?.delete(userFavorit)

            } else {

                favoriteDao?.insert(userFavorit)

            }
        }

    }*/
    fun insertDeleteFavorite(userFavorit: FavoriteUsers, deleteInsert: Boolean) = viewModelScope.launch(Dispatchers.IO){

        if (deleteInsert) {

            favoriteDao?.delete(userFavorit)

        } else {

            favoriteDao?.insert(userFavorit)

        }

    }

    fun getUserFavorite():LiveData<Boolean>{
        return _userFavorit
    }

    fun checkedUserFavorite(id: Int) = viewModelScope.launch{
        val count = favoriteDao?.selectedUsers(id)
        _userFavorit.value = count != 0
    }
}